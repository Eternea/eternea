<?php exit; ?>
1404679045
172
a:5:{s:4:"name";s:7:"eternea";s:9:"copyright";s:25:"&copy; StylerBB.net, 2009";s:7:"version";s:5:"1.0.5";s:12:"inherit_from";s:10:"subsilver2";s:8:"filetime";i:1373142877;}