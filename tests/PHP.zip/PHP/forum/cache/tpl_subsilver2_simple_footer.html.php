<?php if (!defined('IN_PHPBB')) exit; ?></div>

<div id="wrapfooter">
	<span class="copyright"><?php echo (isset($this->_rootref['CREDIT_LINE'])) ? $this->_rootref['CREDIT_LINE'] : ''; ?>

</div>

</body>
</html>