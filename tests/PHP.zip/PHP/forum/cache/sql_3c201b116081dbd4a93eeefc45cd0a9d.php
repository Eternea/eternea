<?php exit; ?>
1373144985
SELECT smiley_id FROM forum_smilies WHERE display_on_posting = 0 LIMIT 1
6
a:0:{}