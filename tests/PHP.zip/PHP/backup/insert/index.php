<?php
$titre = "Administration";
include ("../includes/header.php");
include ("../includes/menu.php");
?>
<p>Administration</p>

<a href="news.php">add</a>
<br>
<a href="baseevent.php">base</a>

<?php
include ("../includes/footer.php");
?>