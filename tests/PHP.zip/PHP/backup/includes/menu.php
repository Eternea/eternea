<!-- menu colonne de gauche -->
<div id="menu">
<p>Menu</p>
<ul>
<li><a href="/projects/test/index.php">accueil</a></li>
<li><a href="/projects/test/frise/index.php">frise</a></li>
<li><a href="/projects/test/insert/index.php">admin</a></li>
<li><a href="/projects/test/recherche/recherche.php">recherche</a></li>
</ul></div>
<div id="contenu">
<h1><?php echo $titre ?></h1>