		</div>
	<!-- footer -->
	<div id="footer"><p>Bas de page</p></div>
	</body>
</html>