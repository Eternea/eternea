<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html dir="ltr" lang="fr">
	<head>
		<meta charset="iso-8859-1" />
		<link rel="stylesheet" type="text/css" media="screen" href="/projects/test/styles/ecran.css" />
		<title><?php echo $titre ?></title>
	</head>
<body>
<?php  
$prenom = 'Francois';
$nom = 'Hoang';
 ?>
	<!-- header -->
	<div id="header">
<h1>frise - test des fonctionnalités</h1>
</div>