<?php
$titre = "Accueil du site";
include ("includes/header.php");
include ("includes/menu.php");

echo '<p>test de frise</p>';

echo '<p>Bonjour '.$prenom.' '.$nom.'</p>';




include ("includes/footer.php");
?>